import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jinge
 */
public class HotelModel {
    final static String hotelKey= "afg5m4y33gaxwz6w2f5u6r94";
    /**
     * constructors
     */
    public HotelModel(){
        
    }
    public String getHotel(String name){
        String url= "http://api.hotwire.com/v1/deal/hotel?dest="+name+
				"&apikey="+hotelKey+"&limit=8";
        //url of this api
        StringBuilder sb= new StringBuilder();
        try{
            DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder= factory.newDocumentBuilder();
	    Document document= builder.parse(url);//parse from the url
            document.getDocumentElement().normalize();
            sb.append("<hotels>");
            sb.append("<city>"+name+"</city>");//xml content
            NodeList nodeList= document.getDocumentElement().getChildNodes();//get nodeList
            for(int i=0;i<nodeList.getLength();i++){
                Node node= nodeList.item(i);//get the i-th node
		if(node.getNodeName().equals("Result")){
                    NodeList childList= node.getChildNodes();
		    for(int j=0;j<childList.getLength();j++){
                        sb.append("<hotel>");
                        Node childNode = childList.item(j);
                        if (childNode instanceof Element) {
                            NodeList attList = childNode.getChildNodes();
                            for (int k = 0; k < attList.getLength(); k++) {
                                Node attNode = attList.item(k);
                                switch (attNode.getNodeName()) {
                                    //according to different head, append the contents into it
                                    case "Headline":
                                        sb.append("headline : " + attNode.getTextContent() + "\n");
                                        break;
                                    case "City":
                                        sb.append("location : " + attNode.getTextContent());
                                        break;
                                    case "NeighborhoodLatitude":
                                        sb.append("(" + attNode.getTextContent() + ",");
                                        break;
                                    case "NeighborhoodLongitude":
                                        sb.append(attNode.getTextContent() + ")");
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        sb.append("</hotel>");
                    }
                }
            }
            sb.append("</hotels>");
        }catch(Exception e){
            
        }
        return sb.toString();
    }
    
}
