/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Servlet for this project
 * myHotel servlet
 * @author gjin
 */
@WebServlet(name= "MyHotels", urlPatterns={"/MyHotels/*"})
public class HotelSearch extends HttpServlet {

    

    /** doGet method
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("console : doGET visited!");
        String path= request.getPathInfo();//get the parameter
        System.out.println("path :"+path);
        HotelModel hotel= new HotelModel();
        if(!path.equals("/")){
            String name = path.substring(1);
            String output= hotel.getHotel(name);
            System.out.println("output :"+output);
            response.setStatus(200);//set the response status to be 200
            response.setContentType("text/plain;charset=UTF-8");
            PrintWriter out= response.getWriter();//write to the stream
            out.println(output);
            return;
        }else {
            response.setStatus(404);//set the response status to be 404
            String output= "<hotels>please type again</hotels>";
            response.setContentType("text/xml;charset=UTF-8");
            PrintWriter out= response.getWriter();
            out.println(output);
            return;
        }
    }
}
