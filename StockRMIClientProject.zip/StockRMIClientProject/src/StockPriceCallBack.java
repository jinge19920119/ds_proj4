/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/** the first type of client
 *
 * @author jinge
 */
public class StockPriceCallBack extends UnicastRemoteObject implements Notifiable{

    public StockPriceCallBack() throws RemoteException{
        
    }
    public static void main(String[] args){
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter user name:");
        while (true) {
            try {
                String name= br.readLine().trim();
                System.out.println("Looking up the server in the registry");
                //connect to the rmiregistry and get a remote reference to the object
                StockRMI stoc= (StockRMI) Naming.lookup("//localhost/stockService");
                System.out.println("Creating a callback object to handle calls from the server");
                Notifiable noti= new StockPriceCallBack();
                
//                System.out.println(noti.getClass());
//                System.out.println(((Notifiable)noti).getClass());
                stoc.registerCallBack(noti, name);
                //stoc.subscribe("demo", "comp");
                System.out.println("Registering the callback with a name at the server");
                System.out.println("Callback handler for StockDealer ready");
                
            } catch (IOException | NotBoundException e) {
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void notify(String stockSym, double price) throws RemoteException {
        System.out.println("stock "+stockSym+"'s price has been updated to "+price);
    }

    @Override
    public void exit() throws RemoteException {
        try {
            UnicastRemoteObject.unexportObject(this, true);
            System.out.println("StockPriceCallBack exiting.");
        } catch (Exception e){ 
            System.out.println("Exception thrown" + e); 
        }
    }
    
}
