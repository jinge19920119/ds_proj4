/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.Naming;
import java.util.StringTokenizer;

/** the second type of client used for updating stock price
 *
 * @author jinge
 */
public class StockRMIClientPriceUpdate {
    public static void main(String[] args) throws Exception{
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter stock symbol and price or ! to quit");
        //bind with the remote object on the server side
        StockRMI stoc= (StockRMI) Naming.lookup("//localhost/stockService");
        while (true) {
            try {
                System.out.print("<update>");
                String line= br.readLine();
                if(line.trim().equals("!")){//if typing in "!", just quit the client
                    break;
                }else {
                    StringTokenizer st = new StringTokenizer(line);
                    String v1 = st.nextToken();
                    String v2 = st.nextToken();
                    //read two strings from input
                    double price= Double.parseDouble(v2);
                    //call remote update methods
                    stoc.stockUpdate(v1, price);
                    System.out.println("update successfully!");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
