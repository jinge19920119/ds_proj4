import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.Naming;
import java.util.StringTokenizer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/** the 3rd type of class used for subscription 
 *
 * @author jinge
 */
public class StockRMIClientSubscription {
    public static void main(String[] args) throws Exception{
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter user name:");
        String name= br.readLine().trim();
        //connect to the rmiregistry and get a remote reference to the object
        StockRMI stoc= (StockRMI) Naming.lookup("//localhost/stockService");
        System.out.println("Enter S for subscrible or U for unsubscribe followed by"
                + "the stock symbol of interests. Enter ! to quit");
        while (true) {
            try {
                String line= br.readLine();
                if(line.trim().equals("!")){
                    stoc.deRegisterCallBack(name);
                    break;
                } else if(!line.trim().equals("")) {
                    StringTokenizer st = new StringTokenizer(line);
                    String v1 = st.nextToken();
                    String v2 = st.nextToken();
                    if(v1.equalsIgnoreCase("S")){
                        //subscription
                        stoc.subscribe(name, v2);
                        System.out.println("subscription successfully!");
                    } else if(v1.equalsIgnoreCase("U")){
                        //unsubscription
                        stoc.unSubscribe(name, v2);
                        System.out.println("unsubscription successfully!");
                    }
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
