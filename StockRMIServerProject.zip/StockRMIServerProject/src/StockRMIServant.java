/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
/** StockRMIServant class will implement StockRMI interface 
 * 
 * @author jinge
 */
public class StockRMIServant extends UnicastRemoteObject implements StockRMI {
    /* Given a stock, get a list of users that are interested in that stock. */
    private static Map<String, List> stocks= new TreeMap();
    /* Given a user, get the remote object reference to its callback method. */
    private static Map<String, Notifiable> users= new TreeMap();
    /**
     * constructors
     * @throws RemoteException 
     */
    public StockRMIServant() throws RemoteException{
        
    }
    /**
     * 
     * @param user
     * @param stockSym
     * @return
     * @throws RemoteException 
     */
    @Override
    public boolean subscribe(String user, String stockSym) throws RemoteException {
        if(!users.containsKey(user)){
            //if this user name is not in the list
            System.out.println("invalid user, hasn't registered for callback");
            return false;
        }
        // if this stock name is in the list
        if(stocks.containsKey(stockSym)){
            List users= stocks.get(stockSym);
            if(!users.contains(user)){
                users.add(user);// add the user name to the list
                System.out.println("add user "+user+" to stock "+stockSym);
            }
            
            //if the stock name is not in the list
        }else {
            List<String> userList= new ArrayList<>();
            userList.add(user);
            stocks.put(stockSym, userList);
            System.out.println("add new stock : "+stockSym);
            System.out.println("add user "+user+" to stock "+stockSym);
        }
        return true;
    }

    /**
     * unSubscribe the user from the user list of stocks
     * @param user
     * @param stockSym
     * @return
     * @throws RemoteException 
     */
    @Override
    public boolean unSubscribe(String user, String stockSym) throws RemoteException {
        if(!users.containsKey(user)){//if this user is not in the list, just return
            System.out.println("invalid user, hasn't registered for callback");
            return false;
        }
        if(stocks.containsKey(stockSym)){
            stocks.get(stockSym).remove(user);//remove the user from the stock
            System.out.println("unsubscribe user "+user+" from stock "+stockSym);
        }
        return true;
    }

    /**
     * in stocks find who are interested in this stock, and notify them the price
     * @param stockSym
     * @param price
     * @throws RemoteException 
     */
    @Override
    public void stockUpdate(String stockSym, double price) throws RemoteException {
        if(!stocks.containsKey(stockSym)){ // add new stock if if does not exist in the map
            List<String> userList= new ArrayList<>();
            stocks.put(stockSym, userList);//add the new user list to the map
            System.out.println("add new stock : "+stockSym);
            return;
        }
        List<String> userList= stocks.get(stockSym);
        for(int i=0;i<userList.size();i++){
            String user= userList.get(i);//get the user list and notify
            Notifiable not= users.get(user);
            if(not!=null)
                not.notify(stockSym, price);
        }
    }
    /**
     * listen from the client side and register the username to the map
     * @param remoteClient
     * @param user
     * @throws RemoteException 
     */
    @Override
    public void registerCallBack(Notifiable remoteClient, String user) throws RemoteException {
        users.put(user, remoteClient);//add the remote object to the map
        System.out.println("user registered : "+user);
    }
    /**
     * client will deRigister 
     * @param user
     * @throws RemoteException 
     */
    @Override
    public void deRegisterCallBack(String user) throws RemoteException {
        Notifiable not= users.get(user);
        if(not!=null)
            not.exit();
        users.remove(user);// if the user exists, remove it from the list
    
    }
    
}
