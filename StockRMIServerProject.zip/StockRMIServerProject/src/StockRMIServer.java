/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.rmi.Naming;
import java.rmi.registry.*;

/** serverSide's main route
 *
 * @author jinge
 */
public class StockRMIServer {
    public static void main(String args[]){
        System.out.println("Stock Server Running");
        try {
            // create the servant
            StockRMI stock = new StockRMIServant();
            System.out.println("Created StockRMIServant object");
            System.out.println("Placing in registry");
            // publish to registry 
            Registry registry = LocateRegistry.createRegistry(1099);
            Naming.rebind("stockService", stock);
            System.out.println("CalculatorServant object ready");
        } catch (Exception e) {
            System.out.println("CalculatorServer error main " + e.getMessage());
        }
    }
}
